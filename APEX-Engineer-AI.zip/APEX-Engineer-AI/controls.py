"""In-game control: named actions made of key presses (MFD navigation, pit request, ...).
Everything is configured in config.json -> controls."""
from __future__ import annotations
import logging, threading, time
import winio

DESCRIPTIONS = {
    "pit_request": "request a pit stop at the end of this lap (toggle: sent again it cancels the request)",
    "cancel_pit": "cancel a pit stop request that was made earlier",
    "mfd_open": "open the multi-function display",
    "mfd_close": "close the multi-function display",
    "mfd_next_page": "go to the next MFD page",
    "mfd_prev_page": "go to the previous MFD page",
    "fuel_mix_up": "make the fuel mix richer",
    "fuel_mix_down": "make the fuel mix leaner",
    "ers_mode": "cycle the ERS deployment mode",
}


class Controls:
    def __init__(self, cfg: dict, state):
        self.cfg, self.state = cfg, state
        self.enabled = bool(cfg.get("enabled", True))
        self.dry_run = bool(cfg.get("dry_run", False))
        self.keys = {k: (v or "").lower() for k, v in cfg.get("keys", {}).items()}
        self.sequences = cfg.get("sequences", {})
        self.descriptions = {**DESCRIPTIONS, **cfg.get("descriptions", {})}
        self.pit_requested = False
        self._lock = threading.Lock()
        self._last = {}

    @staticmethod
    def expand(seq):
        out = []
        for item in seq:
            name, _, n = str(item).partition("*")
            name = name.strip()
            try:
                count = max(1, min(30, int(n))) if n else 1
            except ValueError:
                count = 1
            out += [name] * count
        return out

    def _bound(self, name):
        seq = self.expand(self.sequences.get(name) or [])
        return bool(seq) and all(
            step.startswith("wait_") or (self.keys.get(step) and winio.known_key(self.keys[step]))
            for step in seq
        )

    def available(self) -> dict:
        if not self.enabled:
            return {}
        return {n: self.descriptions.get(n, "custom action: " + n.replace("_", " ")) for n in self.sequences if self._bound(n)}

    def missing(self):
        return [n for n in self.sequences if not self._bound(n)]

    def note_state(self):
        if self.state.pit_status in (1, 2):
            self.pit_requested = False

    def execute(self, name: str):
        name = (name or "").strip().lower()
        if not self.enabled:
            return False, "Controls are switched off."
        if name not in self.sequences:
            return False, f"I do not have an action called {name}."
        if not self._bound(name):
            return False, f"The {name.replace('_', ' ')} control is not configured yet."
        if not self.dry_run:
            if not winio.IS_WINDOWS:
                return False, "Key sending only works on Windows."
            if not self.state.live(3.0):
                return False, "The game is not sending telemetry, so I am not pressing anything."
            if self.cfg.get("require_game_focus", True):
                needle = self.cfg.get("window_title_contains", "F1").lower()
                title = winio.foreground_title()
                if needle not in title.lower():
                    logging.warning("Refused '%s': focused window is '%s'", name, title)
                    return False, "The game window is not in focus, so I did not press anything."
        with self._lock:
            now = time.monotonic()
            if now - self._last.get(name, -1e9) < 1.5:
                return False, "Already did that a moment ago."
            self._last[name] = now
            steps = self.expand(self.sequences[name])
            delay = float(self.cfg.get("step_delay", 0.18))
            hold = float(self.cfg.get("key_hold", 0.06))
            for step in steps:
                if step.startswith("wait_"):
                    try:
                        sec = float(step.split("_")[1])
                    except (IndexError, ValueError):
                        sec = 0.5
                    if self.dry_run:
                        print(f"[CONTROLS dry-run] wait {sec}s")
                    time.sleep(sec)
                    continue

                key = self.keys[step]
                if self.dry_run:
                    print(f"[CONTROLS dry-run] {name}: press {key} ({step})")
                else:
                    winio.send_key(key, hold)
                logging.info("CONTROL %s -> %s (%s)%s", name, key, step, " [dry]" if self.dry_run else "")
                time.sleep(delay)

        if name == "pit_request":
            self.pit_requested = not self.pit_requested
        elif name == "cancel_pit":
            self.pit_requested = False
        return True, f"{name} sent" + (" (dry run)" if self.dry_run else "")