@echo off
title Apex Engineer AI v0.4.0
cd /d "%~dp0"
python main.py
pause
