"""Text-to-speech: Edge neural voice -> mp3 -> VLC, pipelined so the next sentence is synthesised
while the previous one is still playing. Supports interrupt (barge-in) and a Windows SAPI fallback."""
from __future__ import annotations
import asyncio, logging, os, queue, shutil, subprocess, tempfile, threading, time


def find_vlc():
    vlc = shutil.which("vlc")
    if vlc:
        return vlc
    for env, default in (("ProgramFiles", r"C:\Program Files"), ("ProgramFiles(x86)", r"C:\Program Files (x86)")):
        p = os.path.join(os.environ.get(env, default), "VideoLAN", "VLC", "vlc.exe")
        if os.path.isfile(p):
            return p
    return None


class Speaker:
    def __init__(self, voice="en-GB-RyanNeural", rate="+3%", enabled=True):
        self.voice, self.rate, self.enabled = voice, rate, enabled
        self.vlc = find_vlc()
        self._epoch = 0
        self._lock = threading.Lock()
        self._pending = 0                       # sentences queued or playing
        self._text_q: queue.Queue = queue.Queue()
        self._audio_q: queue.Queue = queue.Queue()
        self._proc = None
        self._tmp = tempfile.mkdtemp(prefix="apex_voice_")
        self._n = 0
        threading.Thread(target=self._synth_worker, daemon=True).start()
        threading.Thread(target=self._play_worker, daemon=True).start()

    # ---- public --------------------------------------------------------------------------
    def say(self, text: str):
        text = (text or "").strip()
        if not text or not self.enabled:
            return
        with self._lock:
            self._pending += 1
            epoch = self._epoch
        self._text_q.put((epoch, text))

    def is_speaking(self) -> bool:
        return self._pending > 0

    def interrupt(self):
        """Stop whatever is playing and drop everything queued."""
        with self._lock:
            self._epoch += 1
            self._pending = 0
        for q in (self._text_q, self._audio_q):
            try:
                while True:
                    q.get_nowait()
            except queue.Empty:
                pass
        p = self._proc
        if p and p.poll() is None:
            try:
                p.terminate()
            except Exception:
                pass

    # ---- workers -------------------------------------------------------------------------
    def _done(self, epoch):
        with self._lock:
            if epoch == self._epoch and self._pending > 0:
                self._pending -= 1

    def _synth_worker(self):
        while True:
            epoch, text = self._text_q.get()
            if epoch != self._epoch:
                continue
            path = None
            try:
                self._n += 1
                path = os.path.join(self._tmp, f"r{self._n}.mp3")
                asyncio.run(self._synth(text, path))
                if not os.path.exists(path) or os.path.getsize(path) < 1000:
                    raise RuntimeError("Edge TTS produced no audio")
            except Exception as e:
                logging.warning("Neural TTS failed (%s); using Windows voice for this sentence", e)
                path = None
            self._audio_q.put((epoch, text, path))

    async def _synth(self, text, path):
        import edge_tts  # imported lazily so the app still starts without it
        await asyncio.wait_for(edge_tts.Communicate(text, self.voice, rate=self.rate).save(path), timeout=20)

    def _play_worker(self):
        while True:
            epoch, text, path = self._audio_q.get()
            try:
                if epoch != self._epoch:
                    continue
                if path and self.vlc:
                    self._play_vlc(path)
                elif path and os.name == "nt":
                    os.startfile(path)  # cannot be interrupted; only used when VLC is missing
                    time.sleep(max(2.5, min(25, len(text.split()) / 2.4 + 0.8)))
                else:
                    self._play_sapi(text)
            except Exception:
                logging.exception("Audio playback failed")
            finally:
                if path:
                    try:
                        os.remove(path)
                    except OSError:
                        pass
                self._done(epoch)

    def _play_vlc(self, path):
        self._proc = subprocess.Popen([self.vlc, "--intf", "dummy", "--play-and-exit", path],
                                      stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            self._proc.wait(timeout=40)
        except subprocess.TimeoutExpired:
            self._proc.terminate()

    def _play_sapi(self, text):
        if os.name != "nt":
            return
        esc = text.replace("'", "''")
        script = ("Add-Type -AssemblyName System.Speech; $s=New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                  "$v=$s.GetInstalledVoices() | ForEach-Object {$_.VoiceInfo} | Where-Object {$_.Culture.Name -eq 'en-GB'} "
                  "| Select-Object -First 1; if($v){$s.SelectVoice($v.Name)}; $s.Rate=0; "
                  f"$s.Speak('{esc}');")
        self._proc = subprocess.Popen(["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
                                      stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            self._proc.wait(timeout=30)
        except subprocess.TimeoutExpired:
            self._proc.terminate()
