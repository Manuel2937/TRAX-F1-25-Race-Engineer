# Changelog

## GitHub-ready packaging
- Replaced personal defaults with a generic, editable starter configuration.
- Removed the embedded API key from the distributed configuration.
- Set game-control automation to dry-run by default.
- Added a configurable periodic briefing interval (`alerts.periodic_interval_seconds`).
- Removed the silent `[IGNORE]` response-discard path.
- Fixed reply bookkeeping for streamed responses and action results.
- Rewrote the README in English and corrected setup guidance to describe the Groq API integration.

## v0.4.0
- Richer AI radio replies and proactive race briefings.
- Teammate position, lap and pit-lane status when available.
- Direct-address wake words and configurable game-control sequences.
