"""F1 25 UDP telemetry decoding (format 2025). Pure Python, no dependencies."""
from __future__ import annotations
import logging, struct, time
from dataclasses import dataclass

HEADER = struct.Struct("<HBBBBBQfIIBB")                # 29 bytes
LAP = struct.Struct("<IIHBHBHBHBfffBBBBB?BBBBBBBB")    # 46-byte prefix of 57-byte slot
TEL = struct.Struct("<HfffBbH?Bxx4H4B4BH4f")           # 56-byte prefix of 60-byte slot
STATUS = struct.Struct("<BBBB?fffHHB?HBBBbfffBff")     # 50-byte prefix of 55-byte slot
DAMAGE = struct.Struct("<4f4B4B4B6B??BB")              # 38-byte prefix of 46-byte slot
SESSION = struct.Struct("<BbbBHBbBHHB??")              # 16-byte session header section

WEATHER = {0: "clear", 1: "light cloud", 2: "overcast", 3: "light rain", 4: "heavy rain", 5: "storm"}
# Visual compound (what the driver sees on the tyre). 'Actual' C0-C5 ids are NOT soft/medium/hard.
VISUAL_COMPOUNDS = {16: "soft", 17: "medium", 18: "hard", 7: "intermediate", 8: "wet"}
ERS_MODES = {0: "none", 1: "medium", 2: "hotlap", 3: "overtake"}
FUEL_MIXES = {0: "lean", 1: "standard", 2: "rich", 3: "max"}
SESSION_TYPES = {1: "Practice 1", 2: "Practice 2", 3: "Practice 3", 4: "Short practice", 5: "Qualifying 1",
                 6: "Qualifying 2", 7: "Qualifying 3", 8: "Short qualifying", 9: "One-shot qualifying",
                 10: "Sprint shootout 1", 11: "Sprint shootout 2", 12: "Sprint shootout 3",
                 13: "Short sprint shootout", 14: "One-shot sprint shootout", 15: "Race", 16: "Race 2",
                 17: "Race 3", 18: "Time trial"}
RACE_TYPES = (15, 16, 17)
ERS_CAPACITY_MJ = 4.0


def fmt_time(ms):
    if not ms:
        return "--:--.---"
    m, rem = divmod(int(ms), 60000)
    sec, milli = divmod(rem, 1000)
    return f"{m}:{sec:02d}.{milli:03d}"


@dataclass
class State:
    session_time: float = 0.0
    last_packet: float = 0.0          # time.monotonic() of last valid packet
    speed: int | None = None
    gear: int | None = None
    rpm: int | None = None
    throttle: float | None = None
    brake: float | None = None
    lap: int | None = None
    total_laps: int | None = None
    position: int | None = None
    current_ms: int | None = None
    last_ms: int | None = None
    invalid: bool | None = None
    pit_status: int | None = None
    num_pit_stops: int | None = None
    penalties: int | None = None
    warnings: int | None = None
    gap_ahead_ms: int | None = None
    gap_behind_ms: int | None = None
    weather: int | None = None
    track_temp: int | None = None
    air_temp: int | None = None
    safety_car: int | None = None
    session_type: int | None = None
    track_id: int | None = None
    fuel_kg: float | None = None
    fuel_laps: float | None = None
    fuel_mix: int | None = None
    brake_bias: int | None = None
    pit_limiter: bool | None = None
    drs_allowed: bool | None = None
    ers_mj: float | None = None
    ers_mode: int | None = None
    visual_compound: int | None = None
    tyre_age: int | None = None
    wear: tuple | None = None
    tyre_surface: tuple | None = None
    tyre_inner: tuple | None = None
    brake_temps: tuple | None = None
    pressures: tuple | None = None
    engine_temp: int | None = None
    wing_damage: tuple | None = None
    teammate_position: int | None = None
    teammate_lap: int | None = None
    teammate_pit_status: int | None = None
    teammate_index: int | None = None
    teammate_name: str | None = None
    player_team_id: int | None = None
    participant_teams: dict | None = None
    participant_names: dict | None = None

    # ---- convenience -------------------------------------------------
    @property
    def is_race(self):
        return self.session_type in RACE_TYPES

    def live(self, max_age=3.0):
        return self.last_packet > 0 and (time.monotonic() - self.last_packet) < max_age

    def compound_name(self):
        if self.visual_compound is None:
            return None
        return VISUAL_COMPOUNDS.get(self.visual_compound, f"compound {self.visual_compound}")

    def snapshot(self, extra_lines=()):
        """Compact plain-text telemetry summary handed to the LLM on every turn."""
        s = self
        if not s.live(10):
            return "Telemetry: no data from the game right now."
        L = []
        sess = SESSION_TYPES.get(s.session_type, "unknown session")
        L.append(f"Session: {sess}. Lap {s.lap or '?'} of {s.total_laps or '?'}. Position P{s.position or '?'}.")
        L.append(f"Current lap {fmt_time(s.current_ms)}, last lap {fmt_time(s.last_ms)}"
                 + (", current lap INVALID" if s.invalid else "") + ".")
        if s.teammate_index is not None and s.teammate_position:
            pit_note = " in the pit lane" if s.teammate_pit_status in (1, 2) else ""
            teammate = f" ({s.teammate_name})" if s.teammate_name else ""
            L.append(f"Teammate{teammate}: P{s.teammate_position}, lap {s.teammate_lap or '?' }{pit_note}.")
        if s.is_race:
            gaps = []
            if s.gap_ahead_ms is not None and (s.position or 1) > 1:
                gaps.append(f"{s.gap_ahead_ms/1000:.1f}s to the car ahead")
            if s.gap_behind_ms is not None:
                gaps.append(f"{s.gap_behind_ms/1000:.1f}s to the car behind")
            if gaps:
                L.append("Gaps: " + ", ".join(gaps) + ".")
        if s.speed is not None:
            L.append(f"Speed {s.speed} km/h, gear {s.gear}.")
        if s.compound_name():
            L.append(f"Tyres: {s.compound_name()}, {s.tyre_age or 0} laps old.")
        if s.wear:
            L.append("Tyre wear % (RL/RR/FL/FR): " + "/".join(f"{x:.0f}" for x in s.wear) + ".")
        if s.tyre_surface:
            L.append("Tyre surface temps C (RL/RR/FL/FR): " + "/".join(str(x) for x in s.tyre_surface) + ".")
        if s.fuel_kg is not None:
            m = f" Fuel margin to the finish: {s.fuel_laps:+.1f} laps." if s.fuel_laps is not None else ""
            L.append(f"Fuel {s.fuel_kg:.1f} kg, mix {FUEL_MIXES.get(s.fuel_mix, '?')}." + m)
        if s.ers_mj is not None:
            L.append(f"ERS {s.ers_mj:.2f} MJ ({100*s.ers_mj/ERS_CAPACITY_MJ:.0f}% of battery), mode {ERS_MODES.get(s.ers_mode, '?')}.")
        if s.brake_bias is not None:
            L.append(f"Brake bias {s.brake_bias}% front.")
        L.append(f"Weather {WEATHER.get(s.weather, '?')}, track {s.track_temp}C, air {s.air_temp}C.")
        sc = {0: None, 1: "SAFETY CAR", 2: "VIRTUAL SAFETY CAR", 3: "FORMATION LAP"}.get(s.safety_car)
        if sc:
            L.append(f"Status: {sc}.")
        if s.penalties:
            L.append(f"Time penalties: {s.penalties}s. Warnings: {s.warnings or 0}.")
        if s.wing_damage and max(s.wing_damage) > 0:
            L.append(f"Front wing damage L/R: {s.wing_damage[0]}%/{s.wing_damage[1]}%.")
        if s.pit_status in (1, 2):
            L.append("Car is in the pit lane.")
        if s.num_pit_stops:
            L.append(f"Pit stops made: {s.num_pit_stops}.")
        L.extend(extra_lines)
        return "\n".join(L)


def decode(data: bytes, s: State):
    """Decode one UDP packet into the state. Returns packet id or None."""
    if len(data) < HEADER.size:
        return None
    h = HEADER.unpack_from(data)
    fmt, pid, session_time, player = h[0], h[5], h[7], h[10]
    if fmt != 2025 or player >= 22:
        return None
    s.session_time = session_time
    s.last_packet = time.monotonic()
    base = HEADER.size
    try:
        if pid == 1 and len(data) >= 753:
            v = SESSION.unpack_from(data, base)
            s.weather, s.track_temp, s.air_temp, s.total_laps = v[0], v[1], v[2], v[3]
            s.session_type, s.track_id = v[5], v[6]
            # Safety-car status follows spectator fields (3 bytes) and 21 marshal zones (5 bytes each).
            s.safety_car = data[base + SESSION.size + 3 + 21 * 5]
        elif pid == 4 and len(data) >= 1284:
            # F1 25 participant slots are 57 bytes; team ID identifies a constructor teammate.
            teams, names = {}, {}
            for i in range(22):
                off = base + 1 + i * 57
                team_id = data[off + 3]
                raw_name = data[off + 7:off + 39].split(b"\0", 1)[0]
                teams[i] = team_id
                names[i] = raw_name.decode("utf-8", errors="replace").strip() or None
            s.participant_teams, s.participant_names = teams, names
            s.player_team_id = teams.get(player)
        elif pid == 2 and len(data) >= 1285:
            cars = [LAP.unpack_from(data, base + i * 57) for i in range(22)]
            v = cars[player]
            team_id = (s.participant_teams or {}).get(player)
            teammate_idx = next((i for i, tid in (s.participant_teams or {}).items()
                                 if i != player and tid == team_id and tid != 255), None)
            if teammate_idx is not None:
                tv = cars[teammate_idx]
                s.teammate_index = teammate_idx
                s.teammate_name = (s.participant_names or {}).get(teammate_idx)
                s.teammate_position, s.teammate_lap, s.teammate_pit_status = tv[13], tv[14], tv[15]
            else:
                s.teammate_index = None
                s.teammate_name = None
                s.teammate_position = s.teammate_lap = s.teammate_pit_status = None
            s.last_ms, s.current_ms = v[0], v[1]
            s.position, s.lap, s.pit_status, s.num_pit_stops = v[13], v[14], v[15], v[16]
            s.invalid, s.penalties, s.warnings = v[18], v[19], v[20]
            pos = v[13]
            s.gap_ahead_ms = v[6] + v[7] * 60000 if pos > 1 else None
            behind = next((c for c in cars if pos and c[13] == pos + 1), None)
            s.gap_behind_ms = behind[6] + behind[7] * 60000 if behind else None
        elif pid == 6 and len(data) >= 1352:
            v = TEL.unpack_from(data, base + player * 60)
            s.speed, s.throttle, s.brake = v[0], v[1], v[3]
            s.gear, s.rpm = v[5], v[6]
            s.brake_temps, s.tyre_surface, s.tyre_inner = tuple(v[9:13]), tuple(v[13:17]), tuple(v[17:21])
            s.engine_temp, s.pressures = v[21], tuple(v[22:26])
        elif pid == 7 and len(data) >= 1239:
            v = STATUS.unpack_from(data, base + player * 55)
            s.fuel_mix, s.brake_bias, s.pit_limiter = v[2], v[3], v[4]
            s.fuel_kg, s.fuel_laps = v[5], v[7]
            s.drs_allowed = v[11]
            s.visual_compound, s.tyre_age = v[14], v[15]
            s.ers_mj, s.ers_mode = v[19] / 1_000_000, v[20]
        elif pid == 10 and len(data) >= 1041:
            v = DAMAGE.unpack_from(data, base + player * 46)
            s.wear = tuple(v[0:4])
            s.wing_damage = (v[16], v[17])
    except (struct.error, IndexError) as e:
        logging.warning("Decode error packet %s (%d bytes): %s", pid, len(data), e)
    return pid
