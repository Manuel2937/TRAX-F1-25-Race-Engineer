"""Automatic radio calls triggered by telemetry changes (the engineer speaks first)."""
from __future__ import annotations
import time
from telemetry import WEATHER


class Alerts:
    def __init__(self, state, radio, driver="Driver", periodic_interval_seconds=60):
        self.s, self.radio_cb, self.driver = state, radio, driver
        self.periodic_interval_seconds = max(15, int(periodic_interval_seconds))
        self.cooldowns, self.prev = {}, {}
        self.wear_alerted = False
        self.last_periodic = 0.0
        self.last_teammate_state = None
        self.last_gap_call = 0.0

    def radio(self, message, key, seconds=30):
        now = time.monotonic()
        last = self.cooldowns.get(key)
        if last is not None and now - last < seconds:
            return
        self.cooldowns[key] = now
        self.radio_cb(message)

    def _changed(self, key, value):
        """True when value differs from the last seen one (first sighting only stores it)."""
        old = self.prev.get(key, "__unset__")
        self.prev[key] = value
        return old != "__unset__" and old != value

    def update(self, pid):
        s = self.s
        if pid == 1:
            if self._changed("weather", s.weather):
                self.radio(f"{self.driver}, weather update. Conditions are now {WEATHER.get(s.weather, 'changing')}.", "weather", 40)
            old_sc = self.prev.get("sc", "__unset__")
            if self._changed("sc", s.safety_car):
                if s.safety_car == 1:
                    self.radio("Safety car deployed. Keep temperature in the tyres. I am looking at a stop.", "sc", 15)
                elif s.safety_car == 2:
                    self.radio("Virtual safety car. Hold the delta, I will come back with the strategy.", "vsc", 15)
                elif s.safety_car == 0 and old_sc in (1, 2):
                    self.radio("Safety car in this lap. Get the tyres ready for the restart.", "restart", 15)
        elif pid == 2:
            if s.invalid and self.prev.get("invalid") is not True:
                self.radio(f"That lap is deleted, {self.driver}. No stress, reset and go again.", "invalid", 20)
            self.prev["invalid"] = s.invalid
            pen = s.penalties or 0
            if self._changed("pen", pen) and pen > 0:
                self.radio(f"{self.driver}, we have a time penalty. It is now {pen} seconds on the clock.", "penalty", 20)
        elif pid == 10 and s.wear:
            mw = max(s.wear)
            if mw >= 70 and not self.wear_alerted:
                self.radio("Tyre wear is around seventy percent on the worst tyre. Let's talk about the stop.", "wear", 60)
                self.wear_alerted = True
            elif mw < 60:
                self.wear_alerted = False
        elif pid == 7 and s.fuel_laps is not None and s.is_race and (s.lap or 0) > 1:
            # In races F1 25 reports a fuel *margin* to the finish, not laps remaining.
            if s.fuel_laps < -0.2:
                self.radio(f"Fuel warning. The game says we are {abs(s.fuel_laps):.1f} laps short. Start lifting and coasting.", "fuel-low", 60)


    def periodic(self):
        """Regular, useful radio briefings; deliberately rate-limited to avoid chatter."""
        s = self.s
        now = time.monotonic()
        if not s.live(3) or now - self.last_periodic < self.periodic_interval_seconds:
            return
        self.last_periodic = now

        # Teammate status changes are important in co-op and can be reported immediately.
        if s.teammate_index is not None and s.teammate_position:
            state = (s.teammate_position, s.teammate_lap, s.teammate_pit_status in (1, 2))
            if self.last_teammate_state is not None and state[2] != self.last_teammate_state[2]:
                if state[2]:
                    self.radio(f"Update on your teammate: they are coming into the pit lane. They are currently P{state[0]}, on lap {state[1] or 'unknown'}.", "teammate-pit", 10)
                else:
                    self.radio(f"Your teammate is back out on track, currently P{state[0]}, lap {state[1] or 'unknown'}.", "teammate-out", 10)
            self.last_teammate_state = state

        # Build one concise briefing from live values, only when useful.
        parts = []
        if s.is_race and s.position:
            parts.append(f"We are P{s.position}")
        if s.is_race and s.gap_ahead_ms is not None and s.position and s.position > 1:
            parts.append(f"{s.gap_ahead_ms / 1000:.1f} seconds to the car ahead")
        if s.is_race and s.gap_behind_ms is not None:
            parts.append(f"{s.gap_behind_ms / 1000:.1f} seconds behind")
        if s.compound_name():
            parts.append(f"{s.compound_name()} tyres, {s.tyre_age or 0} laps old")
        if s.wear:
            parts.append(f"wear is {max(s.wear):.0f} percent on the worst tyre")
        if s.fuel_laps is not None:
            parts.append(f"fuel margin is {s.fuel_laps:+.1f} laps")
        if s.ers_mj is not None:
            parts.append(f"{s.ers_mj:.1f} megajoules of ERS remaining")
        if s.teammate_index is not None and s.teammate_position:
            status = "in the pit lane" if s.teammate_pit_status in (1, 2) else "on track"
            parts.append(f"teammate P{s.teammate_position}, {status}")
        if parts:
            self.radio_cb(f"{self.driver}, race update. " + ". ".join(parts) + ". Let me know if you want a strategy check.",)
