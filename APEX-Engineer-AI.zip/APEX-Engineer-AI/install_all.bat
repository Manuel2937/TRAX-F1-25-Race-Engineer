@echo off
title Apex Engineer AI - Install
cd /d "%~dp0"
echo Installing Python packages (voice, microphone, speech recognition)...
python -m pip install --upgrade -r requirements.txt
if errorlevel 1 (
  echo.
  echo Installation failed. Send me the error text above.
  pause
  exit /b 1
)
echo.
echo ---------------------------------------------------------------
echo Next:
echo 1. Open config.json and enter your own Groq API key.
echo 2. Choose your driver name, microphone, voice and control bindings.
echo 3. Run check_setup.bat to verify your setup.
echo Get a Groq API key at https://console.groq.com/keys
echo Keep your API key private. Never commit it to GitHub.
echo ---------------------------------------------------------------
pause
