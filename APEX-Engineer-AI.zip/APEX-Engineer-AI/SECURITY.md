# Security

- Never commit API keys, passwords, access tokens, or personal configuration files.
- The checked-in `config.json` is a starter template with an empty API key.
- If a key is accidentally published, revoke it with the provider immediately and create a replacement.
- When reporting bugs, redact secrets from configuration files and logs.
