@echo off
title Apex Engineer AI - Setup check
cd /d "%~dp0"
python main.py --check
pause
