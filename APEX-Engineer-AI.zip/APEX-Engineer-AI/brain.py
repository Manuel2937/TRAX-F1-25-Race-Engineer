"""The engineer's brain: Groq Cloud chat-completions API.
Streams the reply sentence by sentence.
Falls back to simple rules if offline."""
from __future__ import annotations
import json, logging, re, threading, time, urllib.request, urllib.error
from telemetry import WEATHER, ERS_CAPACITY_MJ, fmt_time

ACTION_RE = re.compile(r"\[\s*ACTION\s*:\s*([A-Za-z_]+)\s*\]", re.I)
SENT_RE = re.compile(r"(?<=[.!?])\s+")

SYSTEM = """You are {engineer}, the personal Formula 1 race engineer of {driver}, speaking over team radio during a session of F1 25.
Talk like a real F1 race engineer: calm, sharp, professional, British. Give useful, information-rich updates in 2 to 4 concise spoken sentences; use one sentence only for urgent calls. Never use markdown, bullets, emojis, or lists. Volunteer relevant information without waiting to be asked. Answer the question directly, then add useful telemetry and a practical recommendation. Never invent data. Say numbers naturally ("two point four seconds", "P1").

CRITICAL RADIO RULES:
- PIT STOPS / BOXING: If the driver says "box", "box now", "box box", "box now box", "box this lap", or anything sounding like it (e.g. "books", "bucks", "box no box"):
  1. NEVER stay silent!
  2. ALWAYS immediately reply acknowledging the stop: "Copy {driver}, box this lap. Calling it in."
  3. ALWAYS append [ACTION:pit_request] at the very end of your reply, EVEN IF a pit request was sent earlier!
- DIRECT ADDRESS: If the driver says "Engineer", "Apex", or "Race Engineer", this is ALWAYS addressed to you. Never ignore it. If unclear, say "I'm listening, go ahead."
- TEAMMATE: Use teammate details only when present in telemetry. Report their position, lap and pit-lane status when relevant. Never guess their tyres, setup, strategy, pace, or exact gap.
- Avoid repeating unchanged facts; prioritise safety, strategy, gaps, tyre condition, fuel, ERS and teammate status.
- If the driver says "No box" or cancels: reply "Copy, stay out, staying out."
- Telemetry cannot show other cars' tyres/strategies. Use ONLY the [TELEMETRY] block for real data.
{actions}"""

ACTIONS_ON = """
CAR CONTROLS
You can press in-game controls for the driver. To do so, end your reply with the tag [ACTION:name] (exactly once, at the very end). Available actions:
{lines}
When executing pit request, word your reply as: "Copy, box this lap." [ACTION:pit_request]
{pit_state}"""
ACTIONS_OFF = "\nYou cannot press any controls in the game."


class Brain:
    def __init__(self, cfg: dict, general: dict, state, controls):
        self.cfg, self.state, self.controls = cfg, state, controls
        self.provider = cfg.get("provider", "groq").lower()
        self.api_key = cfg.get("api_key", "").strip()
        self.host = cfg.get("host", "http://127.0.0.1:11434").rstrip("/")
        self.model = cfg.get("model", "openai/gpt-oss-20b" if self.provider == "groq" else "llama3.1:8b")
        self.driver = general.get("driver_name", "Manuel")
        self.engineer = general.get("engineer_name", "Apex")
        self.max_history = int(cfg.get("history_messages", 24))
        self.history: list[dict] = []
        self._lock = threading.Lock()
        self.cancel = threading.Event()
        self.online = None

    def check(self):
        if self.provider == "groq":
            if not self.api_key or "OVDJE_ZALIJEPI" in self.api_key:
                self.online = False
                return False, "Groq API kljuc nije postavljen u config.json!"
            try:
                req = urllib.request.Request(
                    "https://api.groq.com/openai/v1/models",
                    headers={"Authorization": f"Bearer {self.api_key}", "User-Agent": "ApexEngineer/0.3.2"}
                )
                with urllib.request.urlopen(req, timeout=5) as r:
                    data = json.load(r)
                    models = [m.get("id", "") for m in data.get("data", [])]
                    if self.model not in models:
                        active = "openai/gpt-oss-20b" if "openai/gpt-oss-20b" in models else (models[0] if models else self.model)
                        self.model = active
                    self.online = True
                    return True, f"Groq Cloud povezan (model: '{self.model}'). 0% lokalnog opterecenja."
            except Exception as e:
                self.online = False
                return False, f"Groq API greska: {e}"
        else:
            self.online = False
            return False, f"Unsupported LLM provider '{self.provider}'. This version currently supports Groq."

    def warmup(self):
        if self.provider == "groq":
            print(f"[LLM] Groq Cloud spreman. Model: {self.model}")
            return

    def note_radio(self, text):
        with self._lock:
            self.history.append({"role": "assistant", "content": f"(radio) {text}"})
            self._trim()

    def _trim(self):
        if len(self.history) > self.max_history:
            del self.history[: len(self.history) - self.max_history]
            while self.history and self.history[0]["role"] != "user":
                del self.history[0]

    def _system_prompt(self):
        avail = self.controls.available() if self.controls else {}
        if avail:
            lines = "\n".join(f"- {n}: {d}" for n, d in avail.items())
            pit = ("Pit request status: Active." if self.controls.pit_requested else "Pit request status: None.")
            actions = ACTIONS_ON.format(lines=lines, pit_state=pit)
        else:
            actions = ACTIONS_OFF
        return SYSTEM.format(engineer=self.engineer, driver=self.driver, actions=actions)

    def reply(self, user_text: str, on_sentence, on_action):
        self.cancel.clear()
        snap = self.state.snapshot()
        messages = [{"role": "system", "content": self._system_prompt()}]
        with self._lock:
            messages += self.history
        wake = bool(re.search(r"\b(engineer|apex|race engineer)\b", user_text, re.I))
        direct = ("\n[DIRECT ADDRESS: The driver explicitly called you. You MUST answer; never return [IGNORE]. If unclear, acknowledge and ask what they need.]"
                  if wake else "")
        messages.append({"role": "user", "content": f"[TELEMETRY]\n{snap}\n[/TELEMETRY]\n\n{self.driver}: {user_text}{direct}"})

        spoken, actions, buf = [], [], ""
        t_start, t_first = time.monotonic(), []
        def flush(text):
            # Always process the engineer's response; do not silently discard turns.
            text = re.sub(r"\[\s*IGNORE\s*\]", "", text, flags=re.I).strip()
            for m in ACTION_RE.finditer(text):
                actions.append(m.group(1).lower())
            clean = ACTION_RE.sub("", text).strip()
            if clean:
                spoken.append(clean)
                on_sentence(clean)

        try:
            body = json.dumps({
                "model": self.model,
                "messages": messages,
                "stream": True,
                "temperature": float(self.cfg.get("temperature", 0.5)),
                "max_tokens": int(self.cfg.get("max_tokens", 280))
            }).encode("utf-8")
            req = urllib.request.Request(
                "https://api.groq.com/openai/v1/chat/completions",
                data=body,
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {self.api_key}",
                    "User-Agent": "ApexEngineer/0.3.2"
                }
            )
            with urllib.request.urlopen(req, timeout=25) as r:
                self.online = True
                for raw_line in r:
                    if self.cancel.is_set():
                        break
                    line = raw_line.decode("utf-8").strip()
                    if not line or line.startswith(":"):
                        continue
                    if line == "data: [DONE]":
                        break
                    if line.startswith("data: "):
                        line = line[6:].strip()
                    try:
                        chunk = json.loads(line)
                    except json.JSONDecodeError:
                        continue

                    choices = chunk.get("choices")
                    if not choices:
                        continue
                    piece = choices[0].get("delta", {}).get("content", "")
                    if piece:
                        if not t_first:
                            t_first.append(time.monotonic() - t_start)
                        buf += piece
                        parts = SENT_RE.split(buf)
                        for p in parts[:-1]:
                            flush(p)
                        buf = parts[-1]

            if buf.strip() and not self.cancel.is_set():
                flush(buf)

        except Exception as e:
            self.online = False
            logging.error("LLM greska: %s", e)
            raise ConnectionError(str(e)) from e

        full = " ".join(spoken).strip()
        results = []

        if not self.cancel.is_set():
            for a in dict.fromkeys(actions):
                ok, msg = on_action(a)
                results.append(f"(system: action {a} " + ("executed)" if ok else f"failed - {msg})"))
                if not ok:
                    on_sentence(msg)
                    full = (full + " " + msg).strip()

        with self._lock:
            self.history.append({"role": "user", "content": user_text})
            self.history.append({"role": "assistant", "content": (full + " " + " ".join(results)).strip() or "(no reply)"})
            self._trim()

        return full


class RuleBasedFallback:
    def __init__(self, state, driver="Manuel"):
        self.s, self.driver = state, driver

    def tyres(self):
        s = self.s
        out = []
        if s.compound_name():
            out.append(f"{s.compound_name()}, {s.tyre_age or 0} laps old")
        if s.wear:
            out.append("wear: " + ", ".join(f"{x:.0f} percent" for x in s.wear))
        return "; ".join(out) if out else "Tyre data not available."

    def answer(self, text):
        q, s = text.lower(), self.s
        if any(k in q for k in ("box", "pit")):
            return "Copy, box this lap. Box, box."
        if "tyre" in q or "tire" in q:
            return self.tyres()
        return "Radio check, loud and clear."
