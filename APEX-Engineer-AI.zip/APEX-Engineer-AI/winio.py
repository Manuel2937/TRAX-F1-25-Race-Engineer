"""Windows-only helpers using ctypes (no third-party packages):
   * send_key()         - press a key in the game via SendInput scancodes (works in DirectInput games)
   * foreground_title() - title of the focused window
   * key_down()         - global 'is this key held' check (push-to-talk)
   * joy_buttons()      - state of wheel/joystick buttons via winmm (push-to-talk on a wheel button)
"""
from __future__ import annotations
import ctypes, os, time

IS_WINDOWS = os.name == "nt"

# --- keyboard scancodes (set 1). (scancode, extended) -----------------------------------------
_SC = {"esc": (0x01, 0), "-": (0x0C, 0), "=": (0x0D, 0), "backspace": (0x0E, 0), "tab": (0x0F, 0),
       "enter": (0x1C, 0), "ctrl": (0x1D, 0), "lshift": (0x2A, 0), "rshift": (0x36, 0), "alt": (0x38, 0),
       "space": (0x39, 0), "[": (0x1A, 0), "]": (0x1B, 0), ";": (0x27, 0), "'": (0x28, 0), "`": (0x29, 0),
       "\\": (0x2B, 0), ",": (0x33, 0), ".": (0x34, 0), "/": (0x35, 0),
       "num*": (0x37, 0), "num-": (0x4A, 0), "num+": (0x4E, 0), "num.": (0x53, 0),
       "num/": (0x35, 1), "numenter": (0x1C, 1),
       "up": (0x48, 1), "left": (0x4B, 1), "right": (0x4D, 1), "down": (0x50, 1),
       "home": (0x47, 1), "end": (0x4F, 1), "pageup": (0x49, 1), "pagedown": (0x51, 1),
       "insert": (0x52, 1), "delete": (0x53, 1)}
for i, ch in enumerate("1234567890"):
    _SC[ch] = (0x02 + i, 0)
for ch, code in zip("qwertyuiop", range(0x10, 0x1A)):
    _SC[ch] = (code, 0)
for ch, code in zip("asdfghjkl", range(0x1E, 0x27)):
    _SC[ch] = (code, 0)
for ch, code in zip("zxcvbnm", range(0x2C, 0x33)):
    _SC[ch] = (code, 0)
for n in range(1, 11):
    _SC[f"f{n}"] = (0x3A + n, 0)
_SC["f11"], _SC["f12"] = (0x57, 0), (0x58, 0)
for n, code in zip("789456123", (0x47, 0x48, 0x49, 0x4B, 0x4C, 0x4D, 0x4F, 0x50, 0x51)):
    _SC[f"num{n}"] = (code, 0)
_SC["num0"] = (0x52, 0)

# --- virtual-key codes for push-to-talk polling ------------------------------------------------
_VK = {"space": 0x20, "ctrl": 0x11, "alt": 0x12, "lshift": 0xA0, "rshift": 0xA1, "tab": 0x09,
       "capslock": 0x14, "enter": 0x0D, "backspace": 0x08, "insert": 0x2D, "delete": 0x2E,
       "home": 0x24, "end": 0x23, "pageup": 0x21, "pagedown": 0x22,
       "left": 0x25, "up": 0x26, "right": 0x27, "down": 0x28,
       "num*": 0x6A, "num+": 0x6B, "num-": 0x6D, "num.": 0x6E, "num/": 0x6F,
       "`": 0xC0, ";": 0xBA, "=": 0xBB, ",": 0xBC, "-": 0xBD, ".": 0xBE, "/": 0xBF, "[": 0xDB, "\\": 0xDC, "]": 0xDD, "'": 0xDE}
for i in range(10):
    _VK[str(i)] = 0x30 + i
    _VK[f"num{i}"] = 0x60 + i
for i in range(26):
    _VK[chr(ord("a") + i)] = 0x41 + i
for n in range(1, 13):
    _VK[f"f{n}"] = 0x6F + n


def known_key(name: str) -> bool:
    return name.lower() in _SC


if IS_WINDOWS:
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    winmm = ctypes.windll.winmm
    _PUL = ctypes.POINTER(ctypes.c_ulong)

    class _KeyBdInput(ctypes.Structure):
        _fields_ = [("wVk", ctypes.c_ushort), ("wScan", ctypes.c_ushort), ("dwFlags", ctypes.c_ulong),
                    ("time", ctypes.c_ulong), ("dwExtraInfo", _PUL)]

    class _MouseInput(ctypes.Structure):
        _fields_ = [("dx", ctypes.c_long), ("dy", ctypes.c_long), ("mouseData", ctypes.c_ulong),
                    ("dwFlags", ctypes.c_ulong), ("time", ctypes.c_ulong), ("dwExtraInfo", _PUL)]

    class _HardwareInput(ctypes.Structure):
        _fields_ = [("uMsg", ctypes.c_ulong), ("wParamL", ctypes.c_short), ("wParamH", ctypes.c_ushort)]

    class _InputI(ctypes.Union):
        _fields_ = [("ki", _KeyBdInput), ("mi", _MouseInput), ("hi", _HardwareInput)]

    class _Input(ctypes.Structure):
        _fields_ = [("type", ctypes.c_ulong), ("ii", _InputI)]

    class _JoyInfoEx(ctypes.Structure):
        _fields_ = [(n, ctypes.c_uint32) for n in
                    ("dwSize", "dwFlags", "dwXpos", "dwYpos", "dwZpos", "dwRpos", "dwUpos", "dwVpos",
                     "dwButtons", "dwButtonNumber", "dwPOV", "dwReserved1", "dwReserved2")]

    user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
    user32.GetAsyncKeyState.restype = ctypes.c_short


def _send(scan, ext, up):
    flags = 0x0008 | (0x0002 if up else 0) | (0x0001 if ext else 0)  # SCANCODE | KEYUP | EXTENDED
    extra = ctypes.c_ulong(0)
    ii = _InputI()
    ii.ki = _KeyBdInput(0, scan, flags, 0, ctypes.pointer(extra))
    user32.SendInput(1, ctypes.byref(_Input(1, ii)), ctypes.sizeof(_Input))


def send_key(name: str, hold: float = 0.06):
    """Press and release a key. Raises KeyError for unknown key names."""
    if not IS_WINDOWS:
        raise RuntimeError("Key sending only works on Windows")
    scan, ext = _SC[name.lower()]
    _send(scan, ext, False)
    time.sleep(hold)
    _send(scan, ext, True)


def foreground_title() -> str:
    if not IS_WINDOWS:
        return ""
    hwnd = user32.GetForegroundWindow()
    n = user32.GetWindowTextLengthW(hwnd)
    buf = ctypes.create_unicode_buffer(n + 1)
    user32.GetWindowTextW(hwnd, buf, n + 1)
    return buf.value


def key_down(name: str) -> bool:
    if not IS_WINDOWS:
        return False
    vk = _VK.get(name.lower())
    return bool(vk and (user32.GetAsyncKeyState(vk) & 0x8000))


def joy_buttons(joy_id: int = 0):
    """Bitmask of pressed buttons (bit n = button n, 0-based) or None if the device is missing."""
    if not IS_WINDOWS:
        return None
    info = _JoyInfoEx()
    info.dwSize = ctypes.sizeof(_JoyInfoEx)
    info.dwFlags = 0xFF  # JOY_RETURNALL
    if winmm.joyGetPosEx(joy_id, ctypes.byref(info)) != 0:
        return None
    return info.dwButtons
