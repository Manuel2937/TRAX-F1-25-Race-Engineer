"""Microphone input: push-to-talk (keyboard key or wheel button) or hands-free (voice activity),
transcribed locally with faster-whisper. Nothing is sent to the internet except the one-time model download."""
from __future__ import annotations
import logging, queue, threading, time
import winio

PROMPT = ("Engineer, race engineer, Apex, Manuel, teammate, team mate. Formula 1 race engineer radio. Box box, box now box, pit stop, tyres, soft, medium, hard, intermediate, wet, ERS, DRS, "
          "overtake, undercut, overcut, safety car, virtual safety car, fuel mix, brake bias, delta, gap, lap, sector, "
          "box this lap, stay out, push, lift and coast.")
JUNK = {"you", "thank you", "thanks for watching", "thank you.", "bye", "bye.", ".", "the", "uh", "um", "hmm"}
RATE = 16000
BLOCK = 512  # 32 ms


class Listener:
    def __init__(self, cfg: dict, on_text, on_ptt_down=None, speaker=None):
        self.cfg, self.on_text, self.on_ptt_down, self.speaker = cfg, on_text, on_ptt_down, speaker
        self.mode = cfg.get("mode", "ptt")
        self.model = None
        self._q: queue.Queue = queue.Queue()
        self._stop = threading.Event()
        self._ptt = False
        self._ptt_changed = threading.Event()
        self.ready = threading.Event()

    # ---- lifecycle -----------------------------------------------------------------------
    def start(self):
        threading.Thread(target=self._run, daemon=True, name="listener").start()
        if self.mode == "ptt":
            threading.Thread(target=self._ptt_poll, daemon=True, name="ptt").start()

    def stop(self):
        self._stop.set()

    def _load_model(self):
        from faster_whisper import WhisperModel
        name = self.cfg.get("model", "small.en")
        print(f"[MIC] Loading speech model '{name}' (first run downloads it)...")
        self.model = WhisperModel(name, device=self.cfg.get("device", "cpu"),
                                  compute_type=self.cfg.get("compute_type", "int8"))
        print("[MIC] Speech model ready.")

    # ---- push-to-talk polling ------------------------------------------------------------
    def _ptt_pressed(self):
        key = self.cfg.get("ptt_key")
        if key and winio.key_down(key):
            return True
        btn = self.cfg.get("ptt_joystick_button")
        if btn is not None:
            mask = winio.joy_buttons(int(self.cfg.get("joystick_id", 0)))
            if mask is not None and mask & (1 << int(btn)):
                return True
        return False

    def _ptt_poll(self):
        while not self._stop.is_set():
            now = self._ptt_pressed()
            if now != self._ptt:
                self._ptt = now
                if now and self.on_ptt_down:
                    try:
                        self.on_ptt_down()
                    except Exception:
                        logging.exception("on_ptt_down failed")
            time.sleep(0.01)

    # ---- capture loop --------------------------------------------------------------------
    def _run(self):
        try:
            import numpy as np
            import sounddevice as sd
            self._load_model()
        except Exception as e:
            print(f"[MIC] Microphone disabled: {e}\n      Run install_all.bat, or type your messages instead.")
            logging.exception("Listener init failed")
            return
        self.np = np
        dev = self.cfg.get("device_index")
        try:
            stream = sd.RawInputStream(samplerate=RATE, blocksize=BLOCK, channels=1, dtype="int16",
                                       device=dev, callback=lambda d, f, t, s: self._q.put(bytes(d)))
            stream.start()
        except Exception as e:
            print(f"[MIC] Could not open the microphone: {e}\n      Run: python main.py --devices  and set mic.device_index in config.json")
            logging.exception("Mic open failed")
            return
        self.ready.set()
        if self.mode == "ptt":
            print(f"[MIC] Push-to-talk: hold {self.cfg.get('ptt_key') or ''}"
                  f"{' / wheel button ' + str(self.cfg.get('ptt_joystick_button')) if self.cfg.get('ptt_joystick_button') is not None else ''} and speak.")
            self._loop_ptt()
        else:
            print("[MIC] Hands-free mode: just speak (use a headset so the engineer does not hear himself).")
            self._loop_vad()

    def _loop_ptt(self):
        buf, recording = [], False
        while not self._stop.is_set():
            try:
                chunk = self._q.get(timeout=0.1)
            except queue.Empty:
                continue
            if self._ptt:
                recording = True
                buf.append(chunk)
            elif recording:
                recording = False
                data, buf = b"".join(buf), []
                if len(data) >= RATE * 2 * 0.35:      # ignore taps shorter than ~0.35 s
                    self._transcribe(data)

    def _loop_vad(self):
        np = self.np
        floor, speech, silence, buf = 200.0, 0, 0, []
        min_rms = float(self.cfg.get("vad_threshold", 500))
        end_blocks = int(self.cfg.get("vad_silence_seconds", 0.9) * RATE / BLOCK)
        max_blocks = int(20 * RATE / BLOCK)
        while not self._stop.is_set():
            try:
                chunk = self._q.get(timeout=0.1)
            except queue.Empty:
                continue
            if (self.speaker and self.speaker.is_speaking()
                    and not self.cfg.get("listen_while_speaking", True)):   # speakers: avoid hearing himself
                buf, speech, silence = [], 0, 0
                continue
            rms = float(np.sqrt(np.mean(np.frombuffer(chunk, dtype=np.int16).astype(np.float32) ** 2)))
            loud = rms > max(min_rms, floor * 3)
            if not loud:
                floor = 0.98 * floor + 0.02 * rms
            if loud:
                speech += 1
                silence = 0
                if speech == 3 and self.on_ptt_down and self.speaker and self.speaker.is_speaking():
                    self.on_ptt_down()          # driver started talking: engineer stops (barge-in)
            elif buf:
                silence += 1
            if speech >= 3:
                buf.append(chunk)
                if not loud and silence >= end_blocks or len(buf) > max_blocks:
                    data, buf, speech, silence = b"".join(buf), [], 0, 0
                    self._transcribe(data)
            elif not loud:
                speech = 0
                buf = []
            else:
                buf.append(chunk)   # pre-roll while confirming speech

    # ---- transcription -------------------------------------------------------------------
    def _transcribe(self, raw: bytes):
        np = self.np
        audio = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
        t0 = time.monotonic()
        try:
            segs, _ = self.model.transcribe(audio, language=self.cfg.get("language", "en"), beam_size=1,
                                            vad_filter=True, condition_on_previous_text=False,
                                            initial_prompt=PROMPT)
            text = " ".join(s.text.strip() for s in segs).strip()
        except Exception:
            logging.exception("Transcription failed")
            return
        logging.info("STT (%.1fs audio, %.1fs to transcribe): %s", len(audio) / RATE, time.monotonic() - t0, text)
        if len(text) < 3 or text.lower().strip(" .!?") in JUNK:
            return
        self.on_text(text)
