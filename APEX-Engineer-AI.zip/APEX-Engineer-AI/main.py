"""Apex Engineer AI - voice race engineer for F1 25."""
from __future__ import annotations
import copy, json, logging, os, queue, socket, sys, threading, time
os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")
from collections import Counter, deque
from pathlib import Path

from telemetry import State, decode, fmt_time, WEATHER
from alerts import Alerts
from brain import Brain, RuleBasedFallback
from controls import Controls
from voice_out import Speaker, find_vlc
import winio

VERSION = "0.4.0-github"
HERE = Path(__file__).resolve().parent
DEFAULTS = {
    "driver_name": "Driver", "engineer_name": "Apex", "dashboard": "compact",
    "udp": {"host": "127.0.0.1", "port": 20777},
    "llm": {}, "voice": {}, "mic": {}, "alerts": {}, "controls": {},
}


def load_config():
    cfg = copy.deepcopy(DEFAULTS)
    path = HERE / "config.json"
    if path.exists():
        try:
            user = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as e:
            sys.exit(f"config.json is not valid JSON: {e}")
        for k, v in user.items():
            if isinstance(v, dict) and isinstance(cfg.get(k), dict):
                cfg[k].update(v)
            else:
                cfg[k] = v
    return cfg


# ------------------------------------------------------------------------------------------------
def dashboard(s: State, packets, rate, mode, controls):
    if mode == "off":
        return
    wear = "/".join(f"{x:.0f}" for x in s.wear) if s.wear else "--"
    pit = " | PIT REQ SENT" if controls.pit_requested else ""
    line1 = (f"[{time.strftime('%H:%M:%S')}] Lap {s.lap or '--'}/{s.total_laps or '--'} P{s.position or '--'} | "
             f"{s.speed if s.speed is not None else '--'} km/h | last {fmt_time(s.last_ms)} | "
             f"{(s.compound_name() or '--')} {s.tyre_age or 0}L wear {wear}% | "
             f"fuel {f'{s.fuel_kg:.1f}kg' if s.fuel_kg is not None else '--'} | "
             f"ERS {f'{s.ers_mj:.1f}MJ' if s.ers_mj is not None else '--'} | {packets:,} pkts {rate:.0f}/s{pit}")
    if mode == "compact":
        print(line1)
        return
    print("\n" + "=" * 78)
    print(f" APEX ENGINEER AI v{VERSION}")
    print(line1)
    print(f"Current {fmt_time(s.current_ms)} | Invalid {s.invalid} | Weather {WEATHER.get(s.weather, '--')} "
          f"track {s.track_temp}C air {s.air_temp}C")
    print("=" * 78)


def list_devices():
    import sounddevice as sd
    print(sd.query_devices())
    print("\nSet mic.device_index in config.json to the number of your microphone (input) device.")


def mic_level(cfg, seconds=12):
    import sounddevice as sd, numpy as np
    print(f"Speak normally for {seconds} s. Bars show loudness; vad_threshold should sit between silence and your speech.")
    def cb(data, frames, ti, st):
        rms = float(np.sqrt(np.mean(np.frombuffer(bytes(data), dtype=np.int16).astype(np.float32) ** 2)))
        print(f"{rms:7.0f} " + "#" * min(60, int(rms / 100)))
    with sd.RawInputStream(samplerate=16000, blocksize=4096, channels=1, dtype="int16",
                           device=cfg["mic"].get("device_index"), callback=cb):
        time.sleep(seconds)


def show_buttons(joy_id=0, seconds=15):
    print(f"Press buttons on your wheel/joystick #{joy_id} for {seconds} s...")
    end, seen = time.time() + seconds, set()
    while time.time() < end:
        m = winio.joy_buttons(joy_id)
        if m is None:
            print("No joystick found at that id. Try another joystick_id.")
            return
        for b in range(32):
            if m & (1 << b) and b not in seen:
                seen.add(b)
                print(f"  button {b} pressed  ->  use \"ptt_joystick_button\": {b}")
        time.sleep(0.02)


def self_check(cfg):
    ok = True

    def line(good, msg):
        nonlocal ok
        ok &= bool(good)
        print(("  [OK]   " if good else "  [FAIL] ") + msg)

    print(f"Apex Engineer AI v{VERSION} - setup check\n")
    print("Python packages")
    for mod, why in (("edge_tts", "natural British voice"), ("sounddevice", "microphone"),
                     ("numpy", "audio"), ("faster_whisper", "speech recognition")):
        try:
            __import__(mod)
            line(True, f"{mod} ({why})")
        except Exception as e:
            line(False, f"{mod} missing ({why}): run install_all.bat  [{e}]")
    print("\nVoice output")
    vlc = find_vlc()
    line(vlc, f"VLC found: {vlc}" if vlc else "VLC not found (install it from videolan.org for interruptible, reliable playback)")
    print("\nLanguage model")
    b = Brain(cfg["llm"], cfg, State(), None)
    good, msg = b.check()
    line(good, msg)
    if good:
        print("  Timing a short reply (the first call may load the model, this can take a while)...")
        t0 = time.monotonic()
        try:
            out = []
            b.reply("Radio check, can you hear me?", out.append, lambda a: (False, "n/a"))
            dt = time.monotonic() - t0
            line(dt < 8, f"reply in {dt:.1f}s: {' '.join(out) or '(no reply)'}" + ("" if dt < 8 else "  <- too slow while gaming; try a smaller model"))
        except ConnectionError as e:
            line(False, f"LLM request failed: {e}")
    print("\nMicrophone")
    try:
        import sounddevice as sd
        d = sd.query_devices(cfg["mic"].get("device_index"), "input")
        line(True, f"input device: {d['name']}")
    except Exception as e:
        line(False, f"no usable input device: {e}")
    m = cfg["mic"]
    print(f"  mode={m.get('mode')} ptt_key={m.get('ptt_key')} ptt_joystick_button={m.get('ptt_joystick_button')} model={m.get('model')}")
    print("\nGame controls")
    c = Controls(cfg["controls"], State())
    print(f"  enabled={c.enabled} dry_run={c.dry_run} require_game_focus={cfg['controls'].get('require_game_focus')}")
    print("  configured actions: " + (", ".join(c.available()) or "none yet (bind keys in config.json -> controls.keys)"))
    for n, seq in c.sequences.items():
        for step in c.expand(seq):
            k = c.keys.get(step)
            if k and not winio.known_key(k):
                line(False, f"key '{k}' (for {step}) is not a known key name")
    print("\nResult:", "everything needed is in place." if ok else "fix the [FAIL] items above.")


# ------------------------------------------------------------------------------------------------
def main():
    if "--devices" in sys.argv:
        return list_devices()
    cfg = load_config()
    if "--miclevel" in sys.argv:
        return mic_level(cfg)
    if "--buttons" in sys.argv:
        return show_buttons(int(cfg["mic"].get("joystick_id", 0)))
    if "--check" in sys.argv:
        return self_check(cfg)

    (HERE / "logs").mkdir(exist_ok=True)
    logging.basicConfig(filename=str(HERE / "logs" / "telemetry.log"), level=logging.INFO,
                        format="%(asctime)s %(threadName)s %(message)s", encoding="utf-8")
    driver = cfg["driver_name"]
    state = State()
    speaker = Speaker(cfg["voice"].get("name", "en-GB-RyanNeural"), cfg["voice"].get("rate", "+3%"),
                      cfg["voice"].get("enabled", True))
    controls = Controls(cfg["controls"], state)
    brain = Brain(cfg["llm"], cfg, state, controls)
    fallback = RuleBasedFallback(state, driver)
    utterances: queue.Queue = queue.Queue()

    def radio(message):
        print(f"\n[RADIO] {message}")
        logging.info("RADIO: %s", message)
        brain.note_radio(message)
        speaker.say(message)

    alerts = Alerts(state, radio, driver, cfg["alerts"].get("periodic_interval_seconds", 60))

    # ---- conversation worker: one turn at a time -----------------------------------------
    def say_sentence(text):
        print(f"APEX > {text}")
        speaker.say(text)

    def handle(text, source):
        q = text.lower().strip().strip(".!?")
        if q in ("exit", "quit"):
            utterances.put(None)
            return
        if q == "mute":
            speaker.interrupt(); speaker.enabled = False
            return print("APEX > (radio speaker muted)")
        if q == "unmute":
            speaker.enabled = True
            return say_sentence("Radio is back on.")
        if q in ("controls on", "controls off"):
            controls.enabled = q.endswith("on")
            return print(f"APEX > (controls {'enabled' if controls.enabled else 'disabled'})")
        if q in ("dry on", "dry off"):
            controls.dry_run = q.endswith("on")
            return print(f"APEX > (dry-run {'ON: keys are only printed' if controls.dry_run else 'OFF: keys are really sent to the game'})")
        if q.startswith("do "):
            ok, msg = controls.execute(q[3:])
            return print(f"APEX > (control test) {msg}")
        print(f"\nYOU ({source}) > {text}")
        print("[APEX is thinking...]")
        t0 = time.monotonic()
        try:
            out = brain.reply(text, say_sentence, lambda a: controls.execute(a))
            if not out:
                print(f"[APEX stayed silent after {time.monotonic() - t0:.1f}s - the model decided this was not for him, or the reply was cancelled]")
        except ConnectionError as e:
            logging.warning("LLM unavailable: %s", e)
            if brain.online is False:
                print("[LLM] Not reachable - using basic built-in answers. Check your Groq API key and internet connection.")
            say_sentence(fallback.answer(text))

    def worker():
        while True:
            item = utterances.get()
            if item is None:
                break
            try:
                handle(*item)
            except Exception:
                logging.exception("Conversation error")
                print("[ERROR] see logs/telemetry.log")
        # exit requested
        import os
        print("\nEngineer offline. Good race, " + driver + ".")
        os._exit(0)

    threading.Thread(target=worker, daemon=True, name="conversation").start()

    def on_ptt_down():                      # barge-in: the driver talks, the engineer shuts up
        speaker.interrupt()
        brain.cancel.set()

    # ---- microphone ------------------------------------------------------------------------
    mic_cfg = cfg["mic"]
    if mic_cfg.get("enabled", True):
        from voice_in import Listener
        Listener(mic_cfg, lambda t: utterances.put((t, "mic")), on_ptt_down, speaker).start()

    def stdin_loop():
        while True:
            try:
                t = input()
            except EOFError:
                return
            if t.strip():
                utterances.put((t, "typed"))

    threading.Thread(target=stdin_loop, daemon=True, name="stdin").start()

    # ---- banner ----------------------------------------------------------------------------
    print(f"APEX ENGINEER AI v{VERSION}")
    print(f"Good evening, {driver}. Race engineer online.")
    print(f"Listening on {cfg['udp']['host']}:{cfg['udp']['port']} (F1 25 UDP, format 2025)")
    good, msg = brain.check()
    print(f"[LLM] {msg}")
    if good:
        brain.warmup()
    if not good:
        print("[LLM] Until then I will use basic built-in answers.")
    print(f"[VOICE] {cfg['voice'].get('name')} via {'VLC' if speaker.vlc else 'default MP3 player (install VLC for best results)'}")
    av = controls.available()
    print(f"[CONTROLS] {'DRY-RUN ' if controls.dry_run else ''}actions: {', '.join(av) if av else 'none configured yet (see README)'}")
    print("Type a message and press Enter, or talk. Typed commands: mute, unmute, controls on/off, dry on/off, do <action>, exit.\n")

    # ---- UDP loop --------------------------------------------------------------------------
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((cfg["udp"]["host"], int(cfg["udp"]["port"])))
    sock.settimeout(0.2)
    counts, recent, total, last_ui = Counter(), deque(maxlen=240), 0, 0.0
    try:
        while True:
            try:
                data, _ = sock.recvfrom(4096)
                pid = decode(data, state)
                if pid is not None:
                    total += 1; counts[pid] += 1; recent.append(time.monotonic())
                    alerts.update(pid)
                    controls.note_state()
            except socket.timeout:
                pass
            now = time.monotonic()
            alerts.periodic()
            if now - last_ui > 5:
                rate = (len(recent) - 1) / max(recent[-1] - recent[0], .001) if len(recent) > 1 else 0
                dashboard(state, total, rate, cfg.get("dashboard", "compact"), controls)
                last_ui = now
    except KeyboardInterrupt:
        print("\nEngineer offline. Good race, " + driver + ".")
    finally:
        sock.close()
        speaker.interrupt()


if __name__ == "__main__":
    main()
